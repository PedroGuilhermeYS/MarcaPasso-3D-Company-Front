// src/composables/useImagemUpload.js

import { ref } from 'vue'
import {
  solicitarPresignedProduto,
  solicitarPresignedAvatar,
  uploadParaSupabase,
  confirmarImagemProduto,
  confirmarAvatar
} from '@/api/imagem/imagemApi'

export function useImagemUpload() {
  const uploadando = ref(false)
  const progresso  = ref(0)
  const erro       = ref(null)

  /**
   * Fluxo completo de upload de imagem de produto.
   * @param {File}   arquivo
   * @param {number} produtoId
   * @returns {string|null} URL pública da imagem
   */
  async function uploadImagemProduto(arquivo, produtoId) {
    return _upload(
      () => solicitarPresignedProduto(arquivo),
      arquivo,
      (objectPath) => confirmarImagemProduto(produtoId, objectPath),
      'imagemUrl'
    )
  }

  /**
   * Fluxo completo de upload de avatar do usuário logado.
   * @param {File} arquivo
   * @returns {string|null} URL pública do avatar
   */
  async function uploadAvatar(arquivo) {
    return _upload(
      () => solicitarPresignedAvatar(arquivo),
      arquivo,
      (objectPath) => confirmarAvatar(objectPath),
      'avatarUrl'
    )
  }

  async function _upload(fnPresigned, arquivo, fnConfirmar, campoUrl) {
    uploadando.value = true
    progresso.value  = 0
    erro.value       = null

    try {
      // Passo 1+2: backend gera a presigned URL
      const { uploadUrl, objectPath } = await fnPresigned()

      // Passo 4: frontend faz PUT direto no Supabase
      await uploadParaSupabase(uploadUrl, arquivo, (pct) => {
        progresso.value = pct
      })

      // Passo 5: backend confirma e salva no banco
      const resposta = await fnConfirmar(objectPath)
      return resposta[campoUrl]

    } catch (e) {
      erro.value = e?.message || 'Erro durante o upload'
      console.error('[useImagemUpload]', e)
      return null

    } finally {
      uploadando.value = false
    }
  }

  /**
   * Valida arquivo antes de iniciar o upload.
   * @param {File}   arquivo
   * @param {number} maxMb   padrão 5
   * @returns {string|null}  mensagem de erro ou null se válido
   */
  function validarArquivo(arquivo, maxMb = 5) {
    const tipos = ['image/jpeg', 'image/png', 'image/webp']
    if (!tipos.includes(arquivo.type))
      return `Tipo inválido: ${arquivo.type}. Use JPG, PNG ou WebP.`
    if (arquivo.size > maxMb * 1024 * 1024)
      return `Arquivo muito grande. Máximo: ${maxMb}MB.`
    return null
  }

  return { uploadando, progresso, erro, uploadImagemProduto, uploadAvatar, validarArquivo }
}

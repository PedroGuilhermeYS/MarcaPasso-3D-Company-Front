// src/api/imagem/imagemApi.js

import axiosInstance from '../config'

/**
 * Pede ao backend a presigned URL para imagem de produto (ADMIN).
 * Retorna { uploadUrl, objectPath }
 */
export async function solicitarPresignedProduto(arquivo) {
  const extensao = extrairExtensao(arquivo)
  const { data } = await axiosInstance.post('/imagens/produto/presigned', { extensao })
  return data
}

/**
 * Pede ao backend a presigned URL para avatar do usuário logado.
 * Retorna { uploadUrl, objectPath }
 */
export async function solicitarPresignedAvatar(arquivo) {
  const extensao = extrairExtensao(arquivo)
  const { data } = await axiosInstance.post('/imagens/avatar/presigned', { extensao })
  return data
}

/**
 * Faz o upload do arquivo DIRETAMENTE para o Supabase via presigned URL.
 * Não passa pelo backend — usa XHR para ter barra de progresso.
 *
 * @param {string}   uploadUrl    URL assinada retornada pelo backend
 * @param {File}     arquivo      Arquivo selecionado pelo usuário
 * @param {Function} onProgress   Callback (0–100), opcional
 */
export function uploadParaSupabase(uploadUrl, arquivo, onProgress = null) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()

    if (onProgress) {
      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100))
      })
    }

    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve()
      else reject(new Error(`Upload falhou: ${xhr.status} ${xhr.responseText}`))
    })
    xhr.addEventListener('error', () => reject(new Error('Erro de rede durante o upload')))
    xhr.addEventListener('abort', () => reject(new Error('Upload cancelado')))

    xhr.open('PUT', uploadUrl)
    xhr.setRequestHeader('Content-Type', arquivo.type)
    xhr.send(arquivo)
  })
}

/**
 * Avisa o backend que o upload de produto foi concluído.
 * O backend salva a URL pública no campo imagemPrincipal do produto.
 * Retorna { imagemUrl }
 */
export async function confirmarImagemProduto(produtoId, objectPath) {
  const { data } = await axiosInstance.patch(
    `/imagens/produto/${produtoId}/confirmar`,
    { objectPath }
  )
  return data
}

/**
 * Avisa o backend que o upload do avatar foi concluído.
 * O backend salva a URL pública no campo avatarUrl do usuário.
 * Retorna { avatarUrl }
 */
export async function confirmarAvatar(objectPath) {
  const { data } = await axiosInstance.patch('/imagens/avatar/confirmar', { objectPath })
  return data
}

/**
 * Remove a imagem de um produto (ADMIN).
 */
export async function deletarImagemProduto(produtoId, objectPath) {
  await axiosInstance.delete(`/imagens/produto/${produtoId}`, { data: { objectPath } })
}

// --- helper interno ---
function extrairExtensao(arquivo) {
  const partes = arquivo.name.split('.')
  if (partes.length < 2) throw new Error('Arquivo sem extensão')
  return partes[partes.length - 1].toLowerCase()
}

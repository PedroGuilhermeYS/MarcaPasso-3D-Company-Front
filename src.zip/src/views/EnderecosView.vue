<script setup>
import { ref, onMounted } from 'vue'
import { useAuthStore } from '@/stores/useAuthStore'
import axiosInstance from '@/api/config'

const authStore = useAuthStore()
const enderecos = ref([])

onMounted(async () => {
  const idUsuario = authStore.usuario?.id
  if (idUsuario) {
    const { data } = await axiosInstance.get(`/api/enderecos/${idUsuario}`)
    enderecos.value = data
  }
})

</script>

<template>
  <main class="users">
    <div class="breadcrumb">
      <span>Home</span>
            <span>›</span>
            <span>Minha Conta</span>
            <span>›</span>
            <span class="atual">Favoritos</span>
    </div>

    <div class="page-head">
      <span class="page-icon">📍</span>
      <h1 class="page-titulo">ENDEREÇOS</h1>
    </div>

    <div class="welcome-card">
      <div class="card-top">
        <button class="btn-novo" type="button" @click="cadastrarNovo">
          + CADASTRAR NOVO ENDEREÇO
        </button>
      </div>

      <div class="enderecos-grid">
        <div
          v-for="end in enderecos"
          :key="end.id"
          class="addr-card"
          :class="{ padrao: end.padrao }"
        >
          <div class="card-header">
            <span class="addr-nome">{{ end.nome }}</span>
            <span v-if="end.padrao" class="badge-padrao">(PADRÃO)</span>
          </div>

          <span class="addr-linha">{{ end.rua }}, {{ end.numero }}</span>
          <span v-if="end.complemento" class="addr-linha">{{ end.complemento }}</span>
          <span class="addr-linha">{{ end.bairro }}</span>
          <span class="addr-linha">CEP {{ end.cep }} – {{ end.cidade }}, {{ end.estado }}</span>

          <div class="addr-actions">
            <button class="btn-action" type="button" @click="excluir(end.id)">EXCLUIR</button>
            <button class="btn-action" type="button" @click="editar(end.id)">EDITAR</button>
          </div>
        </div>
      </div>

      <div v-if="!enderecos.length" class="sem-endereco">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="#d7deea">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
          <circle cx="12" cy="9" r="2.5"/>
        </svg>
        <p>Nenhum endereço cadastrado.</p>
      </div>
    </div>
  </main>
</template>

<style scoped>
.breadcrumb {
    display: flex;
    gap: 6px;
    font-size: 13px;
    color: #8f9db8;
    margin-bottom: 16px;
}

.breadcrumb .atual {
    color: #252f4a;
    font-weight: 500;
}

.page-head {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;
}

.page-titulo {
  font-family: 'Syne', sans-serif;
  font-size: 22px;
  font-weight: 800;
  color: #141824;
  margin: 0;
}

/* ── Card principal ─────────────────────────────────── */
.welcome-card {
  background: #ffffff;
  padding: 20px 24px 24px;
  box-shadow: 0 10px 30px rgba(17, 71, 152, 0.08);
  position: relative;
  overflow: hidden;
}

.welcome-card::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, #2c18a0, #114798, #049377);
}

/* ── Botão novo endereço ────────────────────────────── */
.card-top {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 20px;
}

.btn-novo {
  height: 36px;
  padding: 0 16px;
  border: 1.4px solid #ff7a00;
  border-radius: 4px;
  background: transparent;
  color: #ff7a00;
  font-family: 'Syne', sans-serif;
  font-size: 12px;
  font-weight: 800;
  cursor: pointer;
}

.btn-novo:hover {
  background: #fff5ee;
}

/* ── Grid de endereços ──────────────────────────────── */
.enderecos-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

/* ── Card de endereço ───────────────────────────────── */
.addr-card {
  border: 1.4px solid #d7deea;
  border-radius: 4px;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  background: #ffffff;
}

.addr-card.padrao {
  background: #fff5ee;
  border-color: #ffc49a;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 6px;
}

.addr-nome {
  font-family: 'Syne', sans-serif;
  font-size: 13px;
  font-weight: 800;
  color: #141824;
}

.badge-padrao {
  font-family: 'Syne', sans-serif;
  font-size: 11px;
  font-weight: 800;
  color: #ff7a00;
}

.addr-linha {
  font-size: 13px;
  color: #51607f;
  line-height: 1.5;
}

/* ── Ações do card ──────────────────────────────────── */
.addr-actions {
  display: flex;
  gap: 12px;
  align-items: center;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid #edf0f7;
}

.btn-action {
  border: 0;
  background: transparent;
  font-family: 'Syne', sans-serif;
  font-size: 11px;
  font-weight: 800;
  color: #51607f;
  cursor: pointer;
  text-decoration: underline;
  padding: 0;
}

.btn-action:hover {
  color: #141824;
}

.btn-action.tornar {
  margin-left: auto;
  color: #ff7a00;
}

.btn-action.tornar:hover {
  color: #e06a00;
}
</style>
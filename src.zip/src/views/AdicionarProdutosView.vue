<script setup>
import { ref } from 'vue'
import { useProdutosStore } from '@/stores/useProdutosStore'
import { useRouter } from 'vue-router'
import { useImagemUpload } from '@/composables/useImagemUpload'

const produtosStore = useProdutosStore()
const router = useRouter()
const { uploadando, progresso, erro: erroUpload, uploadImagemProduto, validarArquivo } = useImagemUpload()

const nome         = ref('')
const preco        = ref('')
const categoria    = ref('')
const personalizavel = ref(false)
const descricao    = ref('')

// Imagem
const arquivoImagem   = ref(null)
const previewUrl      = ref(null)
const erroImagem      = ref(null)
const inputImagemRef  = ref(null)

const mensagem = ref('')
const loading  = ref(false)

function esperar(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function aoSelecionarImagem(event) {
  erroImagem.value = null
  const arquivo = event.target.files?.[0]
  if (!arquivo) return

  const erro = validarArquivo(arquivo, 5)
  if (erro) {
    erroImagem.value = erro
    return
  }

  arquivoImagem.value = arquivo
  previewUrl.value = URL.createObjectURL(arquivo)
}

function removerImagem() {
  arquivoImagem.value = null
  previewUrl.value = null
  erroImagem.value = null
  if (inputImagemRef.value) inputImagemRef.value.value = ''
}

async function cadastrarProduto() {
  mensagem.value = ''
  loading.value = true

  try {
    // 1. Cadastra o produto SEM imagem primeiro para obter o ID
    const novoProduto = await produtosStore.adicionarProduto({
      nome: nome.value,
      preco: parseFloat(preco.value),
      categoria: categoria.value,
      personalizavel: personalizavel.value,
      descricao: descricao.value,
      imagemPrincipal: null,
    })

    // 2. Se tem imagem, faz o upload agora que temos o ID
    if (arquivoImagem.value && novoProduto?.id) {
      const imagemUrl = await uploadImagemProduto(arquivoImagem.value, novoProduto.id)
      if (!imagemUrl && erroUpload.value) {
        mensagem.value = `⚠️ Produto cadastrado, mas erro no upload da imagem: ${erroUpload.value}`
        await esperar(3000)
        router.push({ name: 'NovoCrud' })
        return
      }
    }

    mensagem.value = '✅ Produto cadastrado com sucesso!'

    nome.value = ''
    preco.value = ''
    categoria.value = ''
    personalizavel.value = false
    descricao.value = ''
    removerImagem()

    await esperar(2000)
    router.push({ name: 'NovoCrud' })

  } catch (error) {
    console.error(error)
    mensagem.value = '❌ Erro ao cadastrar o produto.'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <main class="admin-wrapper">
    <h1 class="titulo">Cadastrar Novo Produto</h1>

    <form @submit.prevent="cadastrarProduto" class="admin-card">

      <div class="input-group">
        <label>Nome do Produto</label>
        <input v-model="nome" placeholder="Ex: Tênis 3D Azul" required />
      </div>

      <div class="row">
        <div class="input-group">
          <label>Preço</label>
          <input v-model="preco" type="number" step="0.01" min="0" placeholder="0,00" required />
        </div>

        <div class="input-group">
          <label>Categoria</label>
          <input v-model="categoria" placeholder="Ex: calcados" required />
        </div>
      </div>

      <label class="checkbox-area">
        <input type="checkbox" v-model="personalizavel" />
        Produto Personalizável
      </label>

      <div class="input-group">
        <label>Descrição</label>
        <textarea v-model="descricao" placeholder="Descreva o produto..." rows="4"></textarea>
      </div>

      <!-- Upload de imagem -->
      <div class="input-group">
        <label>Imagem Principal</label>

        <div
          class="upload-area"
          :class="{ 'tem-preview': previewUrl }"
          @click="inputImagemRef?.click()"
        >
          <img v-if="previewUrl" :src="previewUrl" class="preview-img" alt="Preview" />
          <div v-else class="upload-placeholder">
            <span class="upload-icone">📷</span>
            <span>Clique para selecionar imagem</span>
            <small>JPG, PNG ou WebP · máx. 5MB</small>
          </div>
        </div>

        <input
          ref="inputImagemRef"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          style="display:none"
          @change="aoSelecionarImagem"
        />

        <!-- Barra de progresso durante o upload -->
        <div v-if="uploadando" class="progresso-wrap">
          <div class="progresso-barra" :style="{ width: progresso + '%' }"></div>
          <span class="progresso-texto">Enviando imagem… {{ progresso }}%</span>
        </div>

        <div v-if="previewUrl && !uploadando" class="acoes-imagem">
          <button type="button" class="btn-remover-img" @click="removerImagem">
            ✕ Remover imagem
          </button>
        </div>

        <p v-if="erroImagem" class="msg-erro">{{ erroImagem }}</p>
      </div>

      <button type="submit" :disabled="loading || uploadando" class="btn-submit">
        {{ loading ? 'Cadastrando...' : uploadando ? 'Enviando imagem...' : 'Cadastrar Produto' }}
      </button>

      <p class="mensagem">{{ mensagem }}</p>
    </form>
  </main>
</template>

<style scoped>
.admin-wrapper {
  max-width: 700px;
  margin: 2rem auto;
  font-family: var(--font-family-base);
}
.titulo {
  text-align: center;
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
}
.admin-card {
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
  border: 2px solid var(--color-brand-blue);
  border-radius: 14px;
  padding: 2rem;
}
.input-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.input-group label { font-weight: 600; }
input, textarea {
  padding: 12px;
  border: 1px solid var(--color-border-input);
  border-radius: 10px;
  font-size: 1rem;
  outline: none;
}
input:focus, textarea:focus { border-color: var(--color-brand-blue); }
.row { display: flex; gap: 1.5rem; }
.checkbox-area {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
}

/* Upload */
.upload-area {
  border: 2px dashed var(--color-brand-blue);
  border-radius: 10px;
  height: 180px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  overflow: hidden;
  transition: border-color 0.2s;
}
.upload-area:hover { border-color: #049377; }
.upload-area.tem-preview { border-style: solid; }

.preview-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  color: #888;
  font-size: 0.9rem;
}
.upload-icone { font-size: 2.5rem; }

.progresso-wrap {
  position: relative;
  height: 26px;
  background: #e0e0e0;
  border-radius: 13px;
  overflow: hidden;
  margin-top: 6px;
}
.progresso-barra {
  height: 100%;
  background: var(--color-brand-blue);
  transition: width 0.2s;
}
.progresso-texto {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
  font-weight: 700;
  color: #fff;
}

.acoes-imagem { display: flex; gap: 8px; }
.btn-remover-img {
  padding: 6px 14px;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.85rem;
}

.btn-submit {
  background: var(--color-brand-blue);
  color: white;
  border: none;
  border-radius: 10px;
  padding: 14px;
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
}
.btn-submit:hover { transform: scale(1.02); }
.btn-submit:disabled { opacity: 0.6; cursor: not-allowed; }

.msg-erro { color: #dc3545; font-size: 0.85rem; }
.mensagem { text-align: center; font-weight: 600; }
</style>

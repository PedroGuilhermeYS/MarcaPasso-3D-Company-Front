<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useProdutosStore } from '@/stores/useProdutosStore'
import { useImagemUpload } from '@/composables/useImagemUpload'
import { deletarImagemProduto } from '@/api/imagem/imagemApi'

const route = useRoute()
const produtosStore = useProdutosStore()
const { uploadando, progresso, erro: erroUpload, uploadImagemProduto, validarArquivo } = useImagemUpload()

const id = computed(() => route.params.id)

const nome          = ref('')
const preco         = ref('')
const categoria     = ref('')
const personalizavel = ref(false)
const descricao     = ref('')
const imagemAtual   = ref(null)  // URL atual salva no banco

// Imagem
const arquivoImagem  = ref(null)
const previewUrl     = ref(null)
const erroImagem     = ref(null)
const inputImagemRef = ref(null)

const mensagem = ref('')
const loading  = ref(false)

onMounted(async () => {
  try {
    const p = await produtosStore.buscarProduto(id.value)
    nome.value          = p.nome
    preco.value         = p.preco
    categoria.value     = p.categoria
    personalizavel.value = p.personalizavel
    descricao.value     = p.descricao
    imagemAtual.value   = p.imagemPrincipal || null
  } catch (e) {
    console.error(e)
    mensagem.value = '❌ Erro ao carregar produto.'
  }
})

function aoSelecionarImagem(event) {
  erroImagem.value = null
  const arquivo = event.target.files?.[0]
  if (!arquivo) return

  const erro = validarArquivo(arquivo, 5)
  if (erro) { erroImagem.value = erro; return }

  arquivoImagem.value = arquivo
  previewUrl.value    = URL.createObjectURL(arquivo)
}

function removerNovaImagem() {
  arquivoImagem.value = null
  previewUrl.value    = null
  erroImagem.value    = null
  if (inputImagemRef.value) inputImagemRef.value.value = ''
}

async function removerImagemAtual() {
  if (!imagemAtual.value) return
  try {
    // Extrai o objectPath da URL pública para deletar do Supabase
    // URL pública: https://xxx.supabase.co/storage/v1/object/public/bucket/objectPath
    const partes = imagemAtual.value.split('/public/')
    if (partes.length === 2) {
      const [bucket, ...pathParts] = partes[1].split('/')
      const objectPath = pathParts.join('/')
      await deletarImagemProduto(id.value, objectPath)
    }
    imagemAtual.value = null
    mensagem.value = '✅ Imagem removida.'
  } catch (e) {
    mensagem.value = '❌ Erro ao remover imagem.'
  }
}

async function atualizarProduto() {
  loading.value  = true
  mensagem.value = ''

  try {
    // 1. Atualiza dados do produto
    await produtosStore.atualizarProduto(id.value, {
      nome: nome.value,
      preco: parseFloat(preco.value),
      categoria: categoria.value,
      personalizavel: personalizavel.value,
      descricao: descricao.value,
    })

    // 2. Se selecionou nova imagem, faz o upload
    if (arquivoImagem.value) {
      const novaUrl = await uploadImagemProduto(arquivoImagem.value, id.value)
      if (novaUrl) {
        imagemAtual.value = novaUrl
        removerNovaImagem()
      } else if (erroUpload.value) {
        mensagem.value = `⚠️ Dados atualizados, mas erro na imagem: ${erroUpload.value}`
        return
      }
    }

    mensagem.value = '✅ Produto atualizado com sucesso!'
  } catch (e) {
    console.error(e)
    mensagem.value = '❌ Erro ao atualizar produto.'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <main class="admin-wrapper">
    <h1 class="titulo">Atualizar Produto</h1>

    <form @submit.prevent="atualizarProduto" class="admin-card">

      <div class="input-group">
        <label>Nome</label>
        <input v-model="nome" />
      </div>

      <div class="row">
        <div class="input-group">
          <label>Preço</label>
          <input v-model="preco" type="number" step="0.01" min="0" />
        </div>
        <div class="input-group">
          <label>Categoria</label>
          <input v-model="categoria" />
        </div>
      </div>

      <label class="checkbox-area">
        <input type="checkbox" v-model="personalizavel" />
        Produto Personalizável
      </label>

      <div class="input-group">
        <label>Descrição</label>
        <textarea v-model="descricao" rows="4"></textarea>
      </div>

      <!-- Seção de imagem -->
      <div class="input-group">
        <label>Imagem Principal</label>

        <!-- Imagem atual salva no banco -->
        <div v-if="imagemAtual && !previewUrl" class="imagem-atual-wrap">
          <img :src="imagemAtual" alt="Imagem atual" class="imagem-atual" />
          <div class="imagem-atual-acoes">
            <span class="imagem-atual-label">Imagem atual</span>
            <button type="button" class="btn-trocar" @click="inputImagemRef?.click()">
              🔄 Trocar imagem
            </button>
            <button type="button" class="btn-remover-img" @click="removerImagemAtual">
              🗑️ Remover
            </button>
          </div>
        </div>

        <!-- Área de upload (sem imagem atual ou ao trocar) -->
        <div
          v-if="!imagemAtual || previewUrl"
          class="upload-area"
          :class="{ 'tem-preview': previewUrl }"
          @click="!previewUrl && inputImagemRef?.click()"
        >
          <img v-if="previewUrl" :src="previewUrl" class="preview-img" alt="Nova imagem" />
          <div v-else class="upload-placeholder">
            <span class="upload-icone">📷</span>
            <span>Clique para selecionar imagem</span>
            <small>JPG, PNG ou WebP · máx. 5MB</small>
          </div>
        </div>

        <input
          ref="inputImagemRef"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          style="display:none"
          @change="aoSelecionarImagem"
        />

        <!-- Barra de progresso -->
        <div v-if="uploadando" class="progresso-wrap">
          <div class="progresso-barra" :style="{ width: progresso + '%' }"></div>
          <span class="progresso-texto">Enviando imagem… {{ progresso }}%</span>
        </div>

        <!-- Cancelar nova seleção -->
        <div v-if="previewUrl && !uploadando" class="acoes-imagem">
          <button type="button" class="btn-remover-img" @click="removerNovaImagem">
            ✕ Cancelar nova imagem
          </button>
        </div>

        <p v-if="erroImagem" class="msg-erro">{{ erroImagem }}</p>
      </div>

      <button type="submit" :disabled="loading || uploadando" class="btn-submit">
        {{ loading ? 'Salvando...' : uploadando ? 'Enviando imagem...' : 'Atualizar Produto' }}
      </button>

      <p class="mensagem">{{ mensagem }}</p>
    </form>
  </main>
</template>

<style scoped>
.admin-wrapper {
  max-width: 700px;
  margin: 2rem auto;
  font-family: var(--font-family-base);
}
.titulo {
  text-align: center;
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
}
.admin-card {
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
  border: 2px solid var(--color-brand-blue);
  border-radius: 14px;
  padding: 2rem;
}
.input-group { display: flex; flex-direction: column; gap: 6px; }
.input-group label { font-weight: 600; }
.row { display: flex; gap: 1.5rem; }
input, textarea {
  padding: 12px;
  border: 1px solid var(--color-brand-blue);
  border-radius: 10px;
  font-size: 1rem;
  outline: none;
}
input:focus, textarea:focus { border-color: var(--color-brand-blue); }
.checkbox-area { display: flex; align-items: center; gap: 8px; font-weight: 600; }

/* Imagem atual */
.imagem-atual-wrap {
  display: flex;
  gap: 16px;
  align-items: center;
  padding: 12px;
  border: 1px solid var(--color-border-input, #ddd);
  border-radius: 10px;
}
.imagem-atual {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 8px;
  flex-shrink: 0;
}
.imagem-atual-acoes {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.imagem-atual-label { font-size: 0.85rem; color: #888; }
.btn-trocar {
  padding: 6px 14px;
  background: var(--color-brand-blue);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.85rem;
}

/* Upload */
.upload-area {
  border: 2px dashed var(--color-brand-blue);
  border-radius: 10px;
  height: 160px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  overflow: hidden;
}
.upload-area.tem-preview { border-style: solid; cursor: default; }
.preview-img { width: 100%; height: 100%; object-fit: cover; }
.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  color: #888;
  font-size: 0.9rem;
}
.upload-icone { font-size: 2rem; }

.progresso-wrap {
  position: relative;
  height: 26px;
  background: #e0e0e0;
  border-radius: 13px;
  overflow: hidden;
  margin-top: 6px;
}
.progresso-barra { height: 100%; background: var(--color-brand-blue); transition: width 0.2s; }
.progresso-texto {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  font-size: 0.8rem; font-weight: 700; color: #fff;
}
.acoes-imagem { display: flex; gap: 8px; }
.btn-remover-img {
  padding: 6px 14px;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.85rem;
}

.btn-submit { background: var(--color-brand-blue); color: white; border: none; border-radius: 10px; padding: 14px; font-size: 1rem; font-weight: 700; cursor: pointer; }
.btn-submit:disabled { opacity: 0.6; cursor: not-allowed; }
.msg-erro { color: #dc3545; font-size: 0.85rem; }
.mensagem { text-align: center; font-weight: 600; }
</style>
